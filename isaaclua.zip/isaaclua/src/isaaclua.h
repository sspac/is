/*
 * isaaclua - capa Lua 5.3 para el port de Isaac (Android/arm64).
 *
 * Todas las funciones deben llamarse desde el MISMO hilo (el del juego).
 * Esta libreria NO engancha el juego: expone isaaclua_fire() para que la
 * capa de hooks (vtables del Mach-O) dispare los callbacks.
 */
#ifndef ISAACLUA_H
#define ISAACLUA_H

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define ISAACLUA_API __attribute__((visibility("default")))

/* Tipos de argumento / retorno que cruzan entre C y Lua */
enum { IL_NIL = 0, IL_BOOL, IL_INT, IL_NUM, IL_STR, IL_PTR };

typedef struct IlArg {
    int         type;   /* IL_* */
    int64_t     i;      /* IL_BOOL (0/1) e IL_INT */
    double      n;      /* IL_NUM */
    const char *s;      /* IL_STR (terminada en NUL) */
    void       *p;      /* IL_PTR (llega a Lua como lightuserdata) */
} IlArg;

/* Valor de 'param' que significa "este callback no tiene parametro". */
#define IL_NO_PARAM INT64_MIN

/* Funciones que el port le presta a la capa Lua. Todas opcionales (NULL ok). */
typedef struct IlHost {
    void   (*log)(const char *line);  /* por defecto: logcat en Android, stderr si no */
    int    (*frame_count)(void);      /* Isaac.GetFrameCount() / Game():GetFrameCount() */
    double (*time_ms)(void);          /* Isaac.GetTime(); por defecto reloj monotono */
} IlHost;

/*
 * Crea el estado Lua, carga <scripts_dir>/enums.lua y <scripts_dir>/main.lua,
 * y ejecuta <mods_dir>/<mod>/main.lua de cada mod (orden alfabetico, se salta
 * los que tengan un archivo "disable.it").
 * saves_dir: donde se guardan los datos de mods (SaveModData).
 * scripts_dir puede ser NULL: se usan los main.lua/enums.lua embebidos en el .so.
 * Devuelve el numero de mods cargados sin error (>= 0) o -1 si falla el arranque.
 */
ISAACLUA_API int  isaaclua_boot(const char *scripts_dir, const char *mods_dir,
                                const char *saves_dir, const IlHost *host);
ISAACLUA_API void isaaclua_shutdown(void);

/*
 * Dispara un callback (ids en scripts/enums.lua).
 *  param : filtro del callback (p.ej. id de item) o IL_NO_PARAM.
 *  args  : argumentos que reciben los callbacks tras el 'self' del mod.
 *  ret   : si no es NULL, el despacho se detiene en el primer callback que
 *          devuelva algo distinto de nil y ese valor se copia a *ret
 *          (semantica de los callbacks "PRE_"). Si es NULL se ejecutan todos.
 * Devuelve 1 si hubo valor de retorno, 0 si no, -1 si la capa no esta iniciada.
 * Un callback con error se registra y se salta; nunca derriba al juego.
 * Cada llamada tiene un limite de instrucciones (anti bucles infinitos).
 */
ISAACLUA_API int isaaclua_fire(int callback, int64_t param, int nargs,
                               const IlArg *args, IlArg *ret);

/*
 * Enganche por frame (Android, libisaacport.so). Parchea el slot GOT/PLT de una
 * funcion `void f(void)` que el port llama una vez por frame presentado, y desde
 * ahi dispara MC_POST_UPDATE (cada 'divisor' frames) y MC_POST_RENDER.
 * lib/symbol NULL = "libisaacport.so" / "shim_items_between_frames".
 * Devuelve 0 si se instalo, <0 si no (el log dice por que).
 */
ISAACLUA_API int  isaaclua_install_frame_hook(const char *lib, const char *symbol);
/* Igual, pero si la biblioteca aun no esta cargada reintenta cada 50 ms hasta timeout_ms
 * (0 = 60 s) en un hilo aparte. Devuelve 0 (listo), 1 (pendiente) o <0 (error). */
ISAACLUA_API int  isaaclua_install_frame_hook_async(const char *lib, const char *symbol, int timeout_ms);
ISAACLUA_API void isaaclua_remove_frame_hook(void);
/* POST_UPDATE cada n frames de render (0 = desactivado). Por defecto 2 (60 fps / 30 ups). */
ISAACLUA_API void isaaclua_set_update_divisor(int n);
ISAACLUA_API int  isaaclua_update_count(void);   /* updates disparados hasta ahora */
ISAACLUA_API void isaaclua_note_update(void);

/* Informacion para depuracion / pantalla de mods. */
ISAACLUA_API int isaaclua_mods_loaded(void);
ISAACLUA_API int isaaclua_mods_failed(void);

#ifdef __cplusplus
}
#endif
#endif
