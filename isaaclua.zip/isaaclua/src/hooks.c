/*
 * hooks.c - enganches dentro de isaac.arm64 (el binario de iOS que carga el port).
 *
 * Idea (la misma tecnica de "cuevas" que ya usan los parches v33 del port):
 *   - En la primera instruccion de una funcion del juego se escribe `b cueva`.
 *   - La cueva vive en una pagina propia (mmap) pegada a la imagen, porque los parches v33 del
 *     port ocupan casi todo el relleno de ceros de __TEXT; si no hay pagina cercana se usa ese
 *     relleno como reserva. Solo anota "esto paso":
 *     suma 1 a un contador y guarda x0/x1 en un buzon (memoria de ESTA libreria), ejecuta
 *     la instruccion que se desplazo y vuelve a la 2a instruccion. No llama a Lua.
 *   - Cada frame, libil lee los buzones y dispara los callbacks configurados.
 * Usa x16/x17 como temporales (no se conservan entre llamadas; nada los lee a la entrada).
 *
 * Seguridad: cada sitio se verifica antes (la instruccion actual debe ser la original del
 * binario conocido y no depender de PC); si no coincide se omite y se anota en el registro.
 * Un candidato mal elegido solo dispara callbacks en momentos equivocados: no cambia el juego.
 */
#define _GNU_SOURCE
#include "isaaclua.h"
#include "hooks_table.h"

#include <dlfcn.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>

extern void il_log_ext(const char *line);
extern const char *il_saves_dir(void);
extern int isaaclua_cb_post_update(void);

#define IMG_VM   0x100000000ULL           /* direccion virtual del inicio de __TEXT */
#define TAIL_LO  0x100a81f68ULL           /* fin de __eh_frame: aqui empieza el relleno de ceros */
#define TAIL_HI  0x100a84000ULL           /* fin de __TEXT */
#define CAVE_WORDS 10
#define MAX_FIRE 8
#define LOG_EVERY 120                     /* frames entre escrituras del registro */

typedef struct { volatile uint32_t count; uint32_t pad; volatile uint64_t a0, a1; } Slot;
static Slot g_slots[IL_NCANDS] __attribute__((aligned(64)));

typedef struct { int installed; uint32_t last; int cb; const char *why; } HState;
static HState g_hs[IL_NCANDS];
static void  *g_base = NULL;
static int    g_enabled = 1;                      /* etapa 3 de autoboot; 0 = no instalar enganches de juego */
void il_hooks_enable(int on) { g_enabled = on; }
static int    g_use_own_page = 1;                 /* 0 = forzar el relleno de __TEXT (pruebas) */
void il_hooks_set_own_page(int on) { g_use_own_page = on; }
static int    g_done = 0, g_tries = 0;
static unsigned g_frames = 0, g_last_log = 0;

static const char *cb_names[] = {
    "MC_NPC_UPDATE", "MC_POST_UPDATE", "MC_POST_RENDER", "MC_USE_ITEM", "MC_POST_PEFFECT_UPDATE",
    "MC_USE_CARD", "MC_FAMILIAR_UPDATE", "MC_FAMILIAR_INIT", "MC_EVALUATE_CACHE", "MC_POST_PLAYER_INIT",
    "MC_USE_PILL", "MC_ENTITY_TAKE_DMG", "MC_POST_CURSE_EVAL", "MC_INPUT_ACTION", "MC_LEVEL_GENERATED",
    "MC_POST_GAME_STARTED", "MC_POST_GAME_END", "MC_PRE_GAME_EXIT", "MC_POST_NEW_LEVEL", "MC_POST_NEW_ROOM",
    "MC_GET_CARD", "MC_GET_SHADER_PARAMS", "MC_EXECUTE_CMD", "MC_PRE_USE_ITEM", "MC_PRE_ENTITY_SPAWN",
};
#define N_CB (int)(sizeof cb_names / sizeof cb_names[0])

static void say(const char *fmt, ...) __attribute__((format(printf, 1, 2)));
#include <stdarg.h>
static void say(const char *fmt, ...) {
    char b[400]; va_list ap; va_start(ap, fmt); vsnprintf(b, sizeof b, fmt, ap); va_end(ap); il_log_ext(b);
}

/* ---- codificacion de instrucciones arm64 ------------------------------------- */
static uint32_t enc_movz(int rd, uint32_t imm16, int hw) { return 0xD2800000u | ((uint32_t)hw << 21) | (imm16 << 5) | (uint32_t)rd; }
static uint32_t enc_movk(int rd, uint32_t imm16, int hw) { return 0xF2800000u | ((uint32_t)hw << 21) | (imm16 << 5) | (uint32_t)rd; }
static uint32_t enc_ldr_w(int rt, int rn)  { return 0xB9400000u | ((uint32_t)rn << 5) | (uint32_t)rt; }   /* ldr wt,[xn] */
static uint32_t enc_str_w(int rt, int rn)  { return 0xB9000000u | ((uint32_t)rn << 5) | (uint32_t)rt; }   /* str wt,[xn] */
static uint32_t enc_add_w1(int rd, int rn) { return 0x11000400u | ((uint32_t)rn << 5) | (uint32_t)rd; }   /* add wd,wn,#1 */
static uint32_t enc_stp_x(int rt, int rt2, int rn, int off) {                                            /* stp xt,xt2,[xn,#off] */
    return 0xA9000000u | (((uint32_t)(off / 8) & 0x7f) << 15) | ((uint32_t)rt2 << 10) | ((uint32_t)rn << 5) | (uint32_t)rt;
}
static uint32_t enc_b(uint64_t from, uint64_t to) { return 0x14000000u | ((uint32_t)(((int64_t)to - (int64_t)from) / 4) & 0x03ffffffu); }

/* misma regla que usa el port: la instruccion desplazada no puede depender de PC */
static int pc_independent(uint32_t w) {
    return !((w & 0x1F000000u) == 0x10000000u ||                         /* adr / adrp */
             (w >> 26) == 0x05u || (w >> 26) == 0x25u ||                 /* b / bl */
             (w & 0xFF000010u) == 0x54000000u ||                         /* b.cond */
             ((w >> 25) & 0x3f) == 0x1a || ((w >> 25) & 0x3f) == 0x1b || /* cbz/cbnz, tbz/tbnz */
             (w & 0x3B000000u) == 0x18000000u);                          /* ldr/prfm literal */
}

/* ---- escritura en memoria de codigo ----------------------------------------- */
static int page_prot(uintptr_t addr) {
    FILE *f = fopen("/proc/self/maps", "r");
    if (!f) return PROT_READ | PROT_EXEC;
    char line[512]; int prot = PROT_READ | PROT_EXEC;
    while (fgets(line, sizeof line, f)) {
        unsigned long lo, hi; char perms[8];
        if (sscanf(line, "%lx-%lx %7s", &lo, &hi, perms) == 3 && addr >= lo && addr < hi) {
            prot = 0;
            if (perms[0] == 'r') prot |= PROT_READ;
            if (perms[1] == 'w') prot |= PROT_WRITE;
            if (perms[2] == 'x') prot |= PROT_EXEC;
            break;
        }
    }
    fclose(f);
    return prot;
}

static int write_code(void *dst, const uint32_t *w, size_t n) {
    uintptr_t pg = (uintptr_t)sysconf(_SC_PAGESIZE);
    uintptr_t lo = (uintptr_t)dst & ~(pg - 1);
    uintptr_t hi = (((uintptr_t)dst + n * 4) + pg - 1) & ~(pg - 1);
    int old = page_prot((uintptr_t)dst);
    if (mprotect((void *)lo, hi - lo, PROT_READ | PROT_WRITE | PROT_EXEC) != 0) {
        if (mprotect((void *)lo, hi - lo, PROT_READ | PROT_WRITE) != 0) return -1;
    }
    memcpy(dst, w, n * 4);
    __builtin___clear_cache((char *)dst, (char *)dst + n * 4);
    mprotect((void *)lo, hi - lo, old);
    return 0;
}

/* ---- configuracion: <saves>/hooks.cfg   "nombre = MC_POST_NEW_ROOM" -------------- */
static int cb_from_text(const char *t) {
    for (int i = 0; i < N_CB; i++) if (strcmp(t, cb_names[i]) == 0) return i;
    char *e; long v = strtol(t, &e, 10);
    return (e != t && *e == 0 && v >= 0 && v < 1000) ? (int)v : -1;
}
static void load_cfg(void) {
    for (unsigned i = 0; i < IL_NCANDS; i++) g_hs[i].cb = -1;
    char path[1200]; snprintf(path, sizeof path, "%s/hooks.cfg", il_saves_dir());
    FILE *f = fopen(path, "r");
    if (!f) return;
    char line[256]; int mapped = 0;
    while (fgets(line, sizeof line, f)) {
        char *h = strchr(line, '#'); if (h) *h = 0;
        char *eq = strchr(line, '='); if (!eq) continue;
        *eq = 0; char *k = line, *v = eq + 1;
        while (*k == ' ' || *k == '\t') k++;
        char *e = k + strlen(k); while (e > k && (e[-1] == ' ' || e[-1] == '\t')) *--e = 0;
        while (*v == ' ' || *v == '\t') v++;
        e = v + strlen(v); while (e > v && (e[-1] == ' ' || e[-1] == '\t' || e[-1] == '\n' || e[-1] == '\r')) *--e = 0;
        int cb = cb_from_text(v);
        for (unsigned i = 0; i < IL_NCANDS; i++) {
            if (strcmp(il_cands[i].name, k) == 0) {
                if (cb >= 0) { g_hs[i].cb = cb; mapped++; }
                else say("hooks.cfg: callback desconocido '%s' para %s", v, k);
            }
        }
    }
    fclose(f);
    say("hooks.cfg: %d enganche(s) con callback", mapped);
}

/* ---- buscar el relleno de ceros para las cuevas ------------------------------ */
static uint32_t *g_cursor = NULL, *g_run_end = NULL;
#define MIN_RUN_WORDS 64   /* solo huecos de ceros de >= 256 bytes: los ceros sueltos pueden ser datos de otro parche */
static uint32_t *alloc_cave(void) {
    uint32_t *lo = (uint32_t *)((uintptr_t)g_base + (TAIL_LO - IMG_VM));
    uint32_t *hi = (uint32_t *)((uintptr_t)g_base + (TAIL_HI - IMG_VM));
    const int need = CAVE_WORDS + 1;                          /* +1: hueco de separacion */
    if (!g_cursor) g_cursor = lo;
    uint32_t *p = g_cursor;
    while (p + need <= hi) {
        if (g_run_end && p + need <= g_run_end) { g_cursor = p + need; return p; }
        if (*p != 0) { p++; continue; }
        uint32_t *q = p;
        while (q < hi && *q == 0) q++;
        if ((q - p) >= MIN_RUN_WORDS) {
            g_run_end = q;
            p += 4;                                           /* margen al inicio del hueco */
            g_cursor = p + need;
            return p;
        }
        p = q;                                                /* hueco corto: se ignora */
    }
    return NULL;
}

/* ---- pagina propia para las cuevas, a menos de ~100 MB de la imagen (alcance de `b`) --------- */
#define NEAR_LIMIT 0x6400000ULL     /* 100 MB: margen bajo los +-128 MB de la instruccion b */
static void *own_page(void *base, size_t bytes) {
    size_t pg = (size_t)sysconf(_SC_PAGESIZE);
    size_t len = (bytes + pg - 1) & ~(pg - 1);
    uintptr_t b = (uintptr_t)base;
    for (int k = 1; k <= 96; k++) {
        /* pistas alternadas: justo debajo de la imagen y justo encima de su fin (~11.5 MB) */
        uintptr_t hint = (k & 1) ? b - (uintptr_t)(k / 2 + 1) * 0x40000 : b + 0xb40000 + (uintptr_t)(k / 2) * 0x40000;
        void *p = mmap((void *)hint, len, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
        if (p == MAP_FAILED) continue;
        uintptr_t d = (uintptr_t)p > b ? (uintptr_t)p - b : b - (uintptr_t)p;
        if (d < NEAR_LIMIT) return p;
        munmap(p, len);
    }
    return NULL;
}

typedef struct { unsigned idx; uint32_t *site; uint32_t cur; uint32_t *cave; } Plan;

static void build_cave(uint32_t *out, int *n, unsigned idx, uint32_t *cave, uint32_t *site, uint32_t cur) {
    uint64_t slot = (uint64_t)(uintptr_t)&g_slots[idx];
    int k = 0;
    out[k++] = enc_movz(16, (uint32_t)(slot & 0xffff), 0);
    out[k++] = enc_movk(16, (uint32_t)((slot >> 16) & 0xffff), 1);
    out[k++] = enc_movk(16, (uint32_t)((slot >> 32) & 0xffff), 2);
    if (slot >> 48) out[k++] = enc_movk(16, (uint32_t)(slot >> 48), 3);
    out[k++] = enc_ldr_w(17, 16);
    out[k++] = enc_add_w1(17, 17);
    out[k++] = enc_str_w(17, 16);
    out[k++] = enc_stp_x(0, 1, 16, 8);
    out[k++] = cur;                                                            /* instruccion desplazada */
    out[k] = enc_b((uint64_t)(uintptr_t)(cave + k), (uint64_t)(uintptr_t)(site + 1));   /* a la 2a instruccion */
    k++;
    *n = k;
}

static int near_enough(const void *a, const void *b) {
    uintptr_t x = (uintptr_t)a, y = (uintptr_t)b, d = x > y ? x - y : y - x;
    return d < 0x7800000ULL;
}

int il_hooks_install(void *base) {
    g_base = base;
    load_cfg();

    /* fase 1: validar sitios */
    Plan plan[IL_NCANDS]; unsigned np = 0;
    for (unsigned i = 0; i < IL_NCANDS; i++) {
        const IlCand *c = &il_cands[i];
        uint32_t *site = (uint32_t *)((uintptr_t)base + (c->vm - IMG_VM));
        uint32_t cur = *site;
        if (cur != c->word)       { g_hs[i].why = "la instruccion no es la original (ya parcheada o build distinta)"; continue; }
        if (!pc_independent(cur)) { g_hs[i].why = "la 1a instruccion depende de PC"; continue; }
        plan[np].idx = i; plan[np].site = site; plan[np].cur = cur; plan[np].cave = NULL; np++;
    }

    /* fase 2: sitio para las cuevas */
    uint32_t *page = np && g_use_own_page ? (uint32_t *)own_page(base, (size_t)np * CAVE_WORDS * 4) : NULL;
    int own = page != NULL;
    const char *where = own ? "pagina propia" : "relleno de __TEXT";
    unsigned placed = 0;
    for (unsigned k = 0; k < np; k++) {
        plan[k].cave = own ? page + (size_t)k * CAVE_WORDS : alloc_cave();
        if (!plan[k].cave)                              { g_hs[plan[k].idx].why = "sin espacio para la cueva"; continue; }
        if (!near_enough(plan[k].cave, plan[k].site))   { g_hs[plan[k].idx].why = "la cueva queda fuera del alcance de b"; plan[k].cave = NULL; continue; }
        placed++;
    }

    /* fase 3: escribir las cuevas (y dejarlas ejecutables) ANTES de tocar ningun sitio */
    for (unsigned k = 0; k < np; k++) {
        if (!plan[k].cave) continue;
        uint32_t w[CAVE_WORDS]; int n = 0;
        build_cave(w, &n, plan[k].idx, plan[k].cave, plan[k].site, plan[k].cur);
        if (own) memcpy(plan[k].cave, w, (size_t)n * 4);
        else if (write_code(plan[k].cave, w, (size_t)n) != 0) { g_hs[plan[k].idx].why = "mprotect fallo (cueva)"; plan[k].cave = NULL; }
    }
    if (own) {
        size_t pg = (size_t)sysconf(_SC_PAGESIZE), len = ((size_t)np * CAVE_WORDS * 4 + pg - 1) & ~(pg - 1);
        if (mprotect(page, len, PROT_READ | PROT_EXEC) != 0) {
            say("no se pudo hacer ejecutable la pagina de cuevas; no se instala ningun enganche");
            for (unsigned k = 0; k < np; k++) { plan[k].cave = NULL; g_hs[plan[k].idx].why = "pagina de cuevas no ejecutable"; }
        } else {
            __builtin___clear_cache((char *)page, (char *)page + len);
        }
    }

    /* fase 4: ahora si, desviar cada funcion */
    int ok = 0;
    for (unsigned k = 0; k < np; k++) {
        if (!plan[k].cave) continue;
        uint32_t jump = enc_b((uint64_t)(uintptr_t)plan[k].site, (uint64_t)(uintptr_t)plan[k].cave);
        if (write_code(plan[k].site, &jump, 1) != 0) { g_hs[plan[k].idx].why = "mprotect fallo (sitio)"; continue; }
        g_hs[plan[k].idx].installed = 1; g_hs[plan[k].idx].last = 0; ok++;
    }
    (void)placed;
    say("enganches en isaac.arm64: %d de %d instalados (cuevas en %s)", ok, (int)IL_NCANDS, where);
    for (unsigned i = 0; i < IL_NCANDS; i++)
        if (!g_hs[i].installed) say("  omitido %s: %s", il_cands[i].name, g_hs[i].why ? g_hs[i].why : "?");
    for (unsigned i = 0; i < IL_NCANDS; i++)
        if (g_hs[i].installed && g_hs[i].cb == isaaclua_cb_post_update()) isaaclua_set_update_divisor(0);
    g_done = 1;
    return ok;
}

/* ---- sondeo por frame ------------------------------------------------------------ */
static void write_log(void) {
    char path[1200]; snprintf(path, sizeof path, "%s/hooks_log.txt", il_saves_dir());
    mkdir(il_saves_dir(), 0777);
    FILE *f = fopen(path, "w");
    if (!f) return;
    fprintf(f, "# isaaclua: contadores de los enganches (frames de render: %u)\n", g_frames);
    fprintf(f, "# Anota que contador sube al hacer cada cosa en el juego y mapealo en hooks.cfg\n");
    for (unsigned i = 0; i < IL_NCANDS; i++) {
        if (g_hs[i].installed)
            fprintf(f, "%-20s count=%-8u  callback=%s\n", il_cands[i].name, (unsigned)g_slots[i].count,
                    g_hs[i].cb >= 0 && g_hs[i].cb < N_CB ? cb_names[g_hs[i].cb] : (g_hs[i].cb >= 0 ? "(id)" : "-"));
        else
            fprintf(f, "%-20s OMITIDO: %s\n", il_cands[i].name, g_hs[i].why ? g_hs[i].why : "?");
    }
    fclose(f);
}

static void *find_base(void) {
    void *h = dlopen("libisaacport.so", RTLD_NOW | RTLD_NOLOAD);
    if (!h) return NULL;
    void *(*fn)(void) = (void *(*)(void))dlsym(h, "shim_image_base");
    return fn ? fn() : NULL;
}

void il_hooks_tick(void) {
    g_frames++;
    if (!g_enabled) return;
    if (!g_done) {
        if (g_tries < 600 && (g_frames % 10) == 1) {          /* hasta ~10 s de intentos */
            g_tries++;
            void *b = find_base();
            if (b) il_hooks_install(b);
        }
        if (!g_done) return;
    }
    int changed = 0;
    for (unsigned i = 0; i < IL_NCANDS; i++) {
        if (!g_hs[i].installed) continue;
        uint32_t c = g_slots[i].count, delta = c - g_hs[i].last;
        if (!delta) continue;
        g_hs[i].last = c; changed = 1;
        if (g_hs[i].cb >= 0) {
            IlArg a = { IL_PTR, 0, 0, NULL, (void *)(uintptr_t)g_slots[i].a0 };
            for (uint32_t k = 0; k < delta && k < MAX_FIRE; k++)
                isaaclua_fire(g_hs[i].cb, IL_NO_PARAM, 1, &a, NULL);
        }
    }
    if (changed && g_frames - g_last_log >= LOG_EVERY) { g_last_log = g_frames; write_log(); }
}

/* para pruebas */
uint32_t il_hooks_count(unsigned i) { return i < IL_NCANDS ? g_slots[i].count : 0; }
void il_hooks_bump(unsigned i, uint64_t a0) { if (i < IL_NCANDS) { g_slots[i].a0 = a0; g_slots[i].count++; } }
int il_hooks_installed(unsigned i) { return i < IL_NCANDS && g_hs[i].installed; }
const char *il_hooks_name(unsigned i) { return i < IL_NCANDS ? il_cands[i].name : NULL; }
void il_hooks_reset(void) { g_enabled = 1; memset(g_hs, 0, sizeof g_hs); memset((void *)g_slots, 0, sizeof g_slots); g_cursor = NULL; g_run_end = NULL; g_done = 0; g_tries = 0; g_frames = 0; g_last_log = 0; }
