/*
 * autoboot.c - arranque automatico al cargar libil.so (solo Android).
 * Se compila con -DISAACLUA_AUTOBOOT. libisaacport.so depende de libil.so (parche de DT_NEEDED),
 * asi que el sistema la carga sola.
 *
 * El constructor hace SOLO cosas baratas y seguras (no llama a dlopen/dl_iterate_phdr dentro del
 * cargador): elige carpeta, crea carpetas, abre el registro y lanza un hilo. El arranque de Lua y
 * los enganches ocurren en ese hilo.
 *
 * Diagnostico sin adb:
 *   <base>/isaaclua_log.txt     registro de todo lo que pasa (aparece SIEMPRE si la libreria cargo)
 *   <base>/isaaclua_stage.txt   (opcional) un numero para apagar etapas:
 *        0 = solo registro   1 = + Lua y mods   2 = + enganche por frame   3 = + enganches del juego (por defecto)
 */
#ifdef ISAACLUA_AUTOBOOT
#include "isaaclua.h"
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

extern void il_log_ext(const char *line);
extern void il_logfile_open(const char *path);
extern void il_hooks_enable(int on);

static int dir_exists(const char *p) { struct stat st; return stat(p, &st) == 0 && S_ISDIR(st.st_mode); }

static void mkdir_p(const char *path) {
    char tmp[1200]; snprintf(tmp, sizeof tmp, "%s", path);
    for (char *q = tmp + 1; *q; q++) if (*q == '/') { *q = 0; mkdir(tmp, 0777); *q = '/'; }
    mkdir(tmp, 0777);
}

typedef struct { char mods[1200], saves[1200]; int stage; } Ctx;

static void *boot_thread(void *arg) {
    Ctx c = *(Ctx *)arg; free(arg);
    char b[1300];
    if (c.stage >= 1) {
        int n = isaaclua_boot(NULL, c.mods, c.saves, NULL);   /* scripts embebidos */
        snprintf(b, sizeof b, "etapa 1: Lua listo, %d mod(s) cargados", n); il_log_ext(b);
    } else il_log_ext("etapa 1 desactivada (isaaclua_stage.txt = 0): Lua no se inicia");
    if (c.stage >= 2) {
        int r = isaaclua_install_frame_hook_async(NULL, NULL, 60000);
        snprintf(b, sizeof b, "etapa 2: enganche por frame -> %s", r == 0 ? "instalado" : r > 0 ? "pendiente (reintentando)" : "ERROR"); il_log_ext(b);
    } else il_log_ext("etapa 2 desactivada: sin enganche por frame");
    return NULL;
}

__attribute__((constructor)) static void il_autoboot(void) {
    if (getenv("ISAACLUA_DISABLE")) return;

    char pkg[256] = {0};
    FILE *f = fopen("/proc/self/cmdline", "rb");
    if (f) { size_t n = fread(pkg, 1, sizeof pkg - 1, f); pkg[n] = 0; fclose(f); }
    char *colon = strchr(pkg, ':'); if (colon) *colon = 0;

    /* candidatos de carpeta base (la que contiene mods/). El primero es el que se CREA si no hay ninguno. */
    char cand[8][600]; int nc = 0;
    const char *env = getenv("ISAACLUA_BASE");
    if (env && *env) snprintf(cand[nc++], sizeof cand[0], "%.590s", env);
    snprintf(cand[nc++], sizeof cand[0], "/storage/emulated/0/Android/media/com.tboi.modded1");
    snprintf(cand[nc++], sizeof cand[0], "/storage/emulated/0/Android/media/tboi.reborthmodetc");
    snprintf(cand[nc++], sizeof cand[0], "/storage/emulated/0/Android/media/%.200s", pkg);
    snprintf(cand[nc++], sizeof cand[0], "/storage/emulated/0/Android/data/%.200s/files", pkg);
    snprintf(cand[nc++], sizeof cand[0], "/data/user/0/%.200s/files", pkg);

    char base[600] = {0}; char probe[700];
    for (int i = 0; !base[0] && i < nc; i++) {                         /* 1) alguna con mods/ */
        snprintf(probe, sizeof probe, "%.590s/mods", cand[i]);
        if (dir_exists(probe)) snprintf(base, sizeof base, "%.590s", cand[i]);
    }
    for (int i = 0; !base[0] && i < nc; i++)                           /* 2) alguna que ya exista */
        if (dir_exists(cand[i])) snprintf(base, sizeof base, "%.590s", cand[i]);
    if (!base[0]) snprintf(base, sizeof base, "%.590s", cand[0]);      /* 3) crear la preferida */

    char mods[700], saves[700], logp[700], stagep[700];
    snprintf(mods, sizeof mods, "%.590s/mods", base);
    snprintf(saves, sizeof saves, "%.590s/lua", base);
    snprintf(logp, sizeof logp, "%.590s/isaaclua_log.txt", base);
    snprintf(stagep, sizeof stagep, "%.590s/isaaclua_stage.txt", base);
    mkdir_p(mods); mkdir_p(saves);                                     /* carpetas visibles para el usuario */
    il_logfile_open(logp);

    char b[3000];
    il_log_ext("=== libil.so cargada (constructor) ===");
    snprintf(b, sizeof b, "proceso: %s  pid=%d", pkg, (int)getpid()); il_log_ext(b);
    for (int i = 0; i < nc; i++) {
        snprintf(b, sizeof b, "candidato %s: %.590s", dir_exists(cand[i]) ? "EXISTE " : "no existe", cand[i]); il_log_ext(b);
    }
    snprintf(b, sizeof b, "carpeta base elegida: %.590s", base); il_log_ext(b);
    snprintf(b, sizeof b, "mods: %.690s (%s)", mods, dir_exists(mods) ? "ok" : "NO SE PUDO CREAR"); il_log_ext(b);

    int stage = 3;
    FILE *sf = fopen(stagep, "r");
    if (sf) { int v; if (fscanf(sf, "%d", &v) == 1 && v >= 0 && v <= 3) stage = v; fclose(sf); }
    snprintf(b, sizeof b, "stage=%d (cambialo en %.690s: 0 solo registro, 1 +Lua, 2 +frame, 3 todo)", stage, stagep); il_log_ext(b);
    il_hooks_enable(stage >= 3);

    Ctx *c = (Ctx *)calloc(1, sizeof *c);
    if (!c) return;
    snprintf(c->mods, sizeof c->mods, "%s", mods);
    snprintf(c->saves, sizeof c->saves, "%s", saves);
    c->stage = stage;
    pthread_t th;
    if (pthread_create(&th, NULL, boot_thread, c) == 0) pthread_detach(th);
    else { il_log_ext("no se pudo crear el hilo de arranque"); free(c); }
}
#endif
