/*
 * isaaclua.c - nucleo de la capa Lua 5.3 para el port de Isaac.
 * Ver isaaclua.h para la API publica.
 */
#include "isaaclua.h"
#include "embedded_scripts.h"

#include "lua.h"
#include "lauxlib.h"
#include "lualib.h"

#include <dirent.h>
#include <errno.h>
#include <pthread.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>

#ifdef __ANDROID__
#include <android/log.h>
#endif

/* ---- limites de seguridad ------------------------------------------- */
#define MEM_CAP        ((size_t)192 * 1024 * 1024) /* tope de memoria de Lua   */
#define HOOK_STEP      1000                        /* instrucciones por chequeo */
#define LOAD_BUDGET    200000000LL                 /* instrucciones al cargar   */
#define FIRE_BUDGET    5000000LL                   /* instrucciones por fire    */
#define GRACE_BUDGET   20000LL                     /* margen tras exceder       */
#define MAX_MODS       256
#define MAX_SAVE_BYTES (16 * 1024 * 1024)

/* ---- estado global (un solo estado Lua, un solo hilo) ---------------- */
static lua_State *L = NULL;
static IlHost     g_host;
static char       g_scripts[1024], g_mods[1024], g_saves[1024];
static int        g_api_ref = LUA_NOREF;
static int        g_loaded = 0, g_failed = 0;
static long long  g_budget = 0;
static size_t     g_mem = 0;
static char       g_retbuf[512];
static int        g_update_count = 0;
static pthread_mutex_t g_mu;
static pthread_once_t  g_mu_once = PTHREAD_ONCE_INIT;
static void mu_init(void) {
    pthread_mutexattr_t a;
    pthread_mutexattr_init(&a);
    pthread_mutexattr_settype(&a, PTHREAD_MUTEX_RECURSIVE);
    pthread_mutex_init(&g_mu, &a);
    pthread_mutexattr_destroy(&a);
}
static void lock(void)   { pthread_once(&g_mu_once, mu_init); pthread_mutex_lock(&g_mu); }
static void unlock(void) { pthread_mutex_unlock(&g_mu); }
ISAACLUA_API int  isaaclua_update_count(void) { return g_update_count; }
ISAACLUA_API void isaaclua_note_update(void)  { g_update_count++; }

/* ---- log -------------------------------------------------------------- */
static void default_log(const char *s) {
#ifdef __ANDROID__
    __android_log_print(ANDROID_LOG_INFO, "isaaclua", "%s", s);
#else
    fprintf(stderr, "[isaaclua] %s\n", s);
#endif
}

/* ---- registro en archivo (para ver que paso sin adb) ------------------------------ */
static FILE *g_logfp = NULL;
static pthread_mutex_t g_logmu = PTHREAD_MUTEX_INITIALIZER;
static time_t g_t0 = 0;

void il_logfile_open(const char *path) {
    pthread_mutex_lock(&g_logmu);
    if (!g_logfp) {
        struct stat st;
        const char *mode = (stat(path, &st) == 0 && st.st_size > 256 * 1024) ? "w" : "a";  /* tope ~256 KB */
        g_logfp = fopen(path, mode);
        g_t0 = time(NULL);
    }
    pthread_mutex_unlock(&g_logmu);
}

static void file_log(const char *line) {
    pthread_mutex_lock(&g_logmu);
    if (g_logfp) {
        fprintf(g_logfp, "[+%lds] %s\n", (long)(time(NULL) - g_t0), line);
        fflush(g_logfp);
    }
    pthread_mutex_unlock(&g_logmu);
}

static void il_log(const char *fmt, ...) {
    char buf[1024];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(buf, sizeof buf, fmt, ap);
    va_end(ap);
    if (g_host.log) g_host.log(buf); else default_log(buf);
    file_log(buf);
}

/* usado por frame_hook.c, hooks.c y autoboot.c */
void il_log_ext(const char *line) { il_log("%s", line); }
const char *il_saves_dir(void) { return g_saves; }

/* ---- asignador con tope de memoria ------------------------------------ */
static void *il_alloc(void *ud, void *ptr, size_t osize, size_t nsize) {
    (void)ud;
    size_t old = ptr ? osize : 0; /* con ptr==NULL, osize es una etiqueta de tipo */
    if (nsize == 0) {
        if (ptr) { g_mem -= old; free(ptr); }
        return NULL;
    }
    if (g_mem - old + nsize > MEM_CAP) return NULL;
    void *np = realloc(ptr, nsize);
    if (np) g_mem = g_mem - old + nsize;
    return np;
}

/* ---- vigilante de instrucciones --------------------------------------- */
static void il_hook(lua_State *Ls, lua_Debug *ar) {
    (void)ar;
    g_budget -= HOOK_STEP;
    if (g_budget <= 0) {
        g_budget = GRACE_BUDGET; /* deja correr el manejador de errores */
        luaL_error(Ls, "el script excedio el limite de instrucciones");
    }
}

/* ---- funciones nativas expuestas a main.lua (tabla __il) -------------- */
static int n_log(lua_State *Ls) {
    il_log("%s", luaL_tolstring(Ls, 1, NULL));
    return 0;
}

static int n_frame_count(lua_State *Ls) {
    lua_pushinteger(Ls, g_host.frame_count ? g_host.frame_count() : g_update_count);
    return 1;
}

static int n_time(lua_State *Ls) {
    double ms;
    if (g_host.time_ms) {
        ms = g_host.time_ms();
    } else {
        struct timespec ts;
        clock_gettime(CLOCK_MONOTONIC, &ts);
        ms = (double)ts.tv_sec * 1000.0 + (double)ts.tv_nsec / 1e6;
    }
    lua_pushinteger(Ls, (lua_Integer)ms);
    return 1;
}

/* nombre de mod -> nombre de archivo seguro */
static void safe_name(const char *in, char *out, size_t n) {
    size_t i = 0;
    for (; in[i] && i + 1 < n; i++) {
        char c = in[i];
        int ok = (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
                 (c >= '0' && c <= '9') || c == '_' || c == '-';
        out[i] = ok ? c : '_';
    }
    out[i] = 0;
    if (i == 0) { out[0] = '_'; out[1] = 0; }
}

static void save_path(const char *modname, char *out, size_t n) {
    char nm[256];
    safe_name(modname, nm, sizeof nm);
    snprintf(out, n, "%s/lua_modsave/%s.dat", g_saves, nm);
}

static int n_save(lua_State *Ls) {
    const char *name = luaL_checkstring(Ls, 1);
    size_t len;
    const char *data = luaL_checklstring(Ls, 2, &len);
    char path[1400], tmp[1420], dir[1100];
    if (len > MAX_SAVE_BYTES) { lua_pushboolean(Ls, 0); return 1; }
    save_path(name, path, sizeof path);
    snprintf(dir, sizeof dir, "%s/lua_modsave", g_saves);
    mkdir(g_saves, 0777);
    mkdir(dir, 0777);
    snprintf(tmp, sizeof tmp, "%s.tmp", path);
    FILE *f = fopen(tmp, "wb");
    if (!f) { lua_pushboolean(Ls, 0); return 1; }
    size_t w = fwrite(data, 1, len, f);
    int cl = fclose(f);
    if (w != len || cl != 0 || rename(tmp, path) != 0) {
        remove(tmp);
        lua_pushboolean(Ls, 0);
        return 1;
    }
    lua_pushboolean(Ls, 1);
    return 1;
}

static int n_load(lua_State *Ls) {
    char path[1400];
    save_path(luaL_checkstring(Ls, 1), path, sizeof path);
    FILE *f = fopen(path, "rb");
    if (!f) { lua_pushnil(Ls); return 1; }
    luaL_Buffer b;
    luaL_buffinit(Ls, &b);
    char chunk[4096];
    size_t r, total = 0;
    while ((r = fread(chunk, 1, sizeof chunk, f)) > 0) {
        total += r;
        if (total > MAX_SAVE_BYTES) break;
        luaL_addlstring(&b, chunk, r);
    }
    fclose(f);
    luaL_pushresult(&b);
    return 1;
}

static int n_has(lua_State *Ls) {
    char path[1400];
    save_path(luaL_checkstring(Ls, 1), path, sizeof path);
    struct stat st;
    lua_pushboolean(Ls, stat(path, &st) == 0);
    return 1;
}

static int n_remove(lua_State *Ls) {
    char path[1400];
    save_path(luaL_checkstring(Ls, 1), path, sizeof path);
    lua_pushboolean(Ls, remove(path) == 0);
    return 1;
}

static const luaL_Reg natives[] = {
    {"log", n_log},           {"frame_count", n_frame_count},
    {"time", n_time},         {"save", n_save},
    {"load", n_load},         {"has", n_has},
    {"remove", n_remove},     {NULL, NULL}
};

/* ---- arranque (se ejecuta protegido con lua_pcall) -------------------- */
static int exists(const char *p);

/* Usa <scripts_dir>/<file> si existe; si no, la copia embebida en el .so. */
static void run_script(lua_State *Ls, const char *file, const unsigned char *emb,
                       unsigned int emb_len, int nres) {
    char path[1200];
    int rc;
    snprintf(path, sizeof path, "%s/%s", g_scripts, file);
    if (g_scripts[0] && exists(path)) rc = luaL_loadfile(Ls, path);
    else rc = luaL_loadbuffer(Ls, (const char *)emb, emb_len, file);
    if (rc != LUA_OK) lua_error(Ls);
    lua_call(Ls, 0, nres);
}

static int boot_protected(lua_State *Ls) {
    luaL_openlibs(Ls);
    luaL_newlib(Ls, natives);
    lua_setglobal(Ls, "__il");     /* main.lua lo captura y lo borra */
    run_script(Ls, "enums.lua", il_enums_lua, il_enums_lua_len, 0);
    run_script(Ls, "main.lua", il_main_lua, il_main_lua_len, 1); /* devuelve la tabla api */
    g_api_ref = luaL_ref(Ls, LUA_REGISTRYINDEX);
    return 0;
}

/* ---- carga de mods ---------------------------------------------------- */
static int is_dir(const char *p) { struct stat st; return stat(p, &st) == 0 && S_ISDIR(st.st_mode); }
static int exists(const char *p) { struct stat st; return stat(p, &st) == 0; }
static int cmp_names(const void *a, const void *b) {
    return strcmp(*(char *const *)a, *(char *const *)b);
}

/* llama api.<field>(args...) protegido; devuelve LUA_OK si bien */
static int call_api(const char *field, const char *a, const char *b) {
    int top = lua_gettop(L);
    lua_rawgeti(L, LUA_REGISTRYINDEX, g_api_ref);
    lua_getfield(L, -1, field);
    int n = 0;
    if (a) { lua_pushstring(L, a); n++; }
    if (b) { lua_pushstring(L, b); n++; }
    int rc = lua_pcall(L, n, 0, 0);
    if (rc != LUA_OK) il_log("error interno en %s: %s", field, lua_tostring(L, -1));
    lua_settop(L, top);
    return rc;
}

static void load_one_mod(const char *name, const char *root) {
    char mainlua[1400];
    snprintf(mainlua, sizeof mainlua, "%s/main.lua", root);

    call_api("begin_mod", name, root);

    int top = lua_gettop(L);
    lua_rawgeti(L, LUA_REGISTRYINDEX, g_api_ref);
    lua_getfield(L, -1, "msgh");            /* idx top+2 */
    int msgh = lua_gettop(L);
    int rc = luaL_loadfile(L, mainlua);
    if (rc == LUA_OK) {
        g_budget = LOAD_BUDGET;
        rc = lua_pcall(L, 0, 0, msgh);
    }
    if (rc == LUA_OK) {
        g_loaded++;
        il_log("mod cargado: %s", name);
    } else {
        g_failed++;
        il_log("mod con error: %s\n%s", name, lua_tostring(L, -1));
    }
    lua_settop(L, top);

    call_api("end_mod", NULL, NULL);
}

static void load_mods(void) {
    DIR *d = opendir(g_mods);
    if (!d) { il_log("no se pudo abrir mods_dir: %s", g_mods); return; }
    char *names[MAX_MODS];
    int n = 0;
    struct dirent *e;
    while ((e = readdir(d)) != NULL && n < MAX_MODS) {
        if (e->d_name[0] == '.') continue;
        names[n++] = strdup(e->d_name);
    }
    closedir(d);
    qsort(names, (size_t)n, sizeof names[0], cmp_names);

    for (int i = 0; i < n; i++) {
        char root[1200], probe[1400];
        snprintf(root, sizeof root, "%s/%s", g_mods, names[i]);
        if (is_dir(root)) {
            snprintf(probe, sizeof probe, "%s/disable.it", root);
            if (exists(probe)) {
                il_log("mod desactivado (disable.it): %s", names[i]);
            } else {
                snprintf(probe, sizeof probe, "%s/main.lua", root);
                if (exists(probe)) load_one_mod(names[i], root);
            }
        }
        free(names[i]);
    }
}

/* ---- API publica ------------------------------------------------------ */
static void shutdown_locked(void);

static int boot_locked(const char *scripts_dir, const char *mods_dir,
                       const char *saves_dir, const IlHost *host) {
    if (L) shutdown_locked();
    memset(&g_host, 0, sizeof g_host);
    if (host) g_host = *host;
    snprintf(g_scripts, sizeof g_scripts, "%s", scripts_dir ? scripts_dir : "");
    snprintf(g_mods,    sizeof g_mods,    "%s", mods_dir    ? mods_dir    : "");
    snprintf(g_saves,   sizeof g_saves,   "%s", saves_dir   ? saves_dir   : "");
    g_loaded = g_failed = 0;
    g_mem = 0;

    L = lua_newstate(il_alloc, NULL);
    if (!L) { il_log("no se pudo crear el estado Lua"); return -1; }
    lua_sethook(L, il_hook, LUA_MASKCOUNT, HOOK_STEP);

    g_budget = LOAD_BUDGET;
    lua_pushcfunction(L, boot_protected);
    if (lua_pcall(L, 0, 0, 0) != LUA_OK) {
        il_log("fallo el arranque de Lua: %s", lua_tostring(L, -1));
        lua_close(L);
        L = NULL;
        g_api_ref = LUA_NOREF;
        return -1;
    }

    load_mods();
    il_log("isaaclua listo: %d mod(s) cargados, %d con error", g_loaded, g_failed);
    return g_loaded;
}

static void shutdown_locked(void) {
    if (L) { lua_close(L); L = NULL; }
    g_api_ref = LUA_NOREF;
    g_mem = 0;
}

ISAACLUA_API void isaaclua_shutdown(void) { lock(); shutdown_locked(); unlock(); }

ISAACLUA_API int isaaclua_boot(const char *scripts_dir, const char *mods_dir,
                               const char *saves_dir, const IlHost *host) {
    lock();
    int r = boot_locked(scripts_dir, mods_dir, saves_dir, host);
    unlock();
    return r;
}

static void push_arg(lua_State *Ls, const IlArg *a) {
    switch (a->type) {
    case IL_BOOL: lua_pushboolean(Ls, a->i != 0); break;
    case IL_INT:  lua_pushinteger(Ls, (lua_Integer)a->i); break;
    case IL_NUM:  lua_pushnumber(Ls, a->n); break;
    case IL_STR:  lua_pushstring(Ls, a->s ? a->s : ""); break;
    case IL_PTR:  lua_pushlightuserdata(Ls, a->p); break;
    default:      lua_pushnil(Ls); break;
    }
}

static int fire_locked(int callback, int64_t param, int nargs,
                       const IlArg *args, IlArg *ret) {
    if (!L || g_api_ref == LUA_NOREF) return -1;
    if (nargs < 0) nargs = 0;
    int top = lua_gettop(L);
    if (!lua_checkstack(L, nargs + 8)) return 0;

    lua_rawgeti(L, LUA_REGISTRYINDEX, g_api_ref);
    lua_getfield(L, -1, "dispatch");
    lua_remove(L, -2);
    lua_pushinteger(L, callback);
    if (param == IL_NO_PARAM) lua_pushnil(L); else lua_pushinteger(L, (lua_Integer)param);
    lua_pushboolean(L, ret != NULL);
    for (int i = 0; i < nargs; i++) push_arg(L, &args[i]);

    g_budget = FIRE_BUDGET;
    int got = 0;
    if (lua_pcall(L, 3 + nargs, 1, 0) != LUA_OK) {
        il_log("error al despachar callback %d: %s", callback, lua_tostring(L, -1));
    } else if (ret && !lua_isnil(L, -1)) {
        memset(ret, 0, sizeof *ret);
        switch (lua_type(L, -1)) {
        case LUA_TBOOLEAN: ret->type = IL_BOOL; ret->i = lua_toboolean(L, -1); got = 1; break;
        case LUA_TNUMBER:
            if (lua_isinteger(L, -1)) { ret->type = IL_INT; ret->i = lua_tointeger(L, -1); }
            else                      { ret->type = IL_NUM; ret->n = lua_tonumber(L, -1); }
            got = 1; break;
        case LUA_TSTRING:
            snprintf(g_retbuf, sizeof g_retbuf, "%s", lua_tostring(L, -1));
            ret->type = IL_STR; ret->s = g_retbuf; got = 1; break;
        case LUA_TLIGHTUSERDATA: ret->type = IL_PTR; ret->p = lua_touserdata(L, -1); got = 1; break;
        default: break; /* tablas/funciones no cruzan a C */
        }
    }
    lua_settop(L, top);
    return got;
}

ISAACLUA_API int isaaclua_fire(int callback, int64_t param, int nargs,
                               const IlArg *args, IlArg *ret) {
    lock();
    int r = fire_locked(callback, param, nargs, args, ret);
    unlock();
    return r;
}

ISAACLUA_API int isaaclua_mods_loaded(void) { lock(); int v = g_loaded; unlock(); return v; }
ISAACLUA_API int isaaclua_mods_failed(void) { lock(); int v = g_failed; unlock(); return v; }
