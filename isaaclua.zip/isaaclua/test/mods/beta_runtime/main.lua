local mod = RegisterMod("BetaRuntime", 1)
mod:AddPriorityCallback(ModCallbacks.MC_POST_UPDATE, CallbackPriority.IMPORTANT, function(self)
    error("fallo a proposito")
end)
mod:AddCallback(ModCallbacks.MC_POST_RENDER, function(self)
    while true do end                       -- bucle infinito
end)
mod:AddCallback(ModCallbacks.MC_EVALUATE_CACHE, function(self)
    local x = string.rep("x", 1024 * 1024 * 1024)   -- pide 1 GB
    return #x
end)
