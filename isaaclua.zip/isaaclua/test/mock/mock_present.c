extern void mock_item_frame(void);
/* esta TU llama a la funcion por la PLT, igual que el port llama a shim_*_between_frames */
__attribute__((noinline, visibility("default"))) void mock_present(void) { mock_item_frame(); }
