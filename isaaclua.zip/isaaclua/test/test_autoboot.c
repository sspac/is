/* Prueba del constructor de autoboot (en PC): carpetas, registro, etapas y arranque de Lua. */
#include "../src/isaaclua.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

int main(int argc, char **argv) {
    int want = argc > 1 ? atoi(argv[1]) : 1;                /* mods que se esperan cargar */
    for (int i = 0; i < 60 && isaaclua_mods_loaded() < want; i++) usleep(50 * 1000);
    if (want == 0) usleep(500 * 1000);                      /* dar tiempo al hilo para que escriba su registro */
    printf("mods_cargados=%d\n", isaaclua_mods_loaded());
    return isaaclua_mods_loaded() == want ? 0 : 1;
}
