# Puntos del juego que el port ya conoce (libisaacport.so -> isaac.arm64)

`shim_trace_add(offset, etiqueta)` registra una sonda en `image_base + offset`. Antes de hacerlo el port
comprueba los primeros bytes de la funcion contra valores esperados, asi que **los offsets son de este
binario exacto (1.77)**. Las etiquetas son las del autor del port (el 1er caracter de cada cadena es un
prefijo interno que quito). No he verificado que hace cada funcion: la etiqueta es la unica pista.
Solo listo los offsets que el port escribe como constante; el resto se calcula en tiempo de ejecucion.

| offset en la imagen | etiqueta del port |
|---|---|
| `0x7f2278` | anm2 path |
| `0x7f822c` | music track |
| `0x862f04` | hold the stick |
| `0x6e3a88` | options menu |
| `0x671c8c` | sound played |
| `0x5e78ac` | character screen input |
| `0x70065c` | save has been read |
| `0x7f8e34` | plaque: screen 3 update |
| `0x85fb98` | touch group draw |
| `0x864434` | item button action |
| `0x861d1c` | widgets are walked |
| `0x670a00` | the fit |
| `0x597d34` | the controls screen draws |
| `0x6fdd80` | the effects are wiped |
| `0x8de4e4` | a surface is born |
| `0x76436c` | the entity list |
| `0x578490` | the hud draw |
| `0x6ee608` | the HUD's corners are laid |
| `0x6efac4` | the stats column |
| `0x5c2630` | the room is drawn |
| `0x88e9cc` | the room is laid |
| `0x6a9314` | the rooms slide |
| `0x7691c8` | the menu is drawn |
| `0x89e550` | a layer render |

(Sondas con direccion calculada, sin offset fijo: show the stick, pause button, difficulty widget drawn, difficulty chosen, run request B, plaque: screen 3 draw, the run request as it is served, every touch widget, bomb button, widget action, the other list, the button row, the menu screen switch, the menu box test, the finger in units, the overlay draw, a button is touched, the menu is laid)
