-- enums.lua - constantes globales de la API de Isaac que usa isaaclua.
-- Los IDs de callback son los que la capa de hooks pasa a isaaclua_fire().
-- Los mods usan los NOMBRES (ModCallbacks.MC_POST_UPDATE), asi que lo
-- importante es que hooks y esta tabla coincidan. Para anadir un callback:
-- agrega aqui la linea y dispara ese ID desde el hook.

ModCallbacks = {
    MC_NPC_UPDATE           = 0,
    MC_POST_UPDATE          = 1,
    MC_POST_RENDER          = 2,
    MC_USE_ITEM             = 3,
    MC_POST_PEFFECT_UPDATE  = 4,
    MC_USE_CARD             = 5,
    MC_FAMILIAR_UPDATE      = 6,
    MC_FAMILIAR_INIT        = 7,
    MC_EVALUATE_CACHE       = 8,
    MC_POST_PLAYER_INIT     = 9,
    MC_USE_PILL             = 10,
    MC_ENTITY_TAKE_DMG      = 11,
    MC_POST_CURSE_EVAL      = 12,
    MC_INPUT_ACTION         = 13,
    MC_LEVEL_GENERATED      = 14,
    MC_POST_GAME_STARTED    = 15,
    MC_POST_GAME_END        = 16,
    MC_PRE_GAME_EXIT        = 17,
    MC_POST_NEW_LEVEL       = 18,
    MC_POST_NEW_ROOM        = 19,
    MC_GET_CARD             = 20,
    MC_GET_SHADER_PARAMS    = 21,
    MC_EXECUTE_CMD          = 22,
    MC_PRE_USE_ITEM         = 23,
    MC_PRE_ENTITY_SPAWN     = 24,
}

CallbackPriority = {
    IMPORTANT = -200,
    EARLY     = -100,
    DEFAULT   = 0,
    LATE      = 100,
    LATER     = 200,
}
