# isaaclua — capa Lua 5.3 para el port de Isaac (paquete com.tboi.modded1)

Mods en Lua para el port, sin tocar el código del juego (`isaac.arm64`). Carga los `main.lua` de
`Android/media/com.tboi.modded1/mods/<mod>/` y dispara callbacks desde una función por-frame del port.

## Qué hay en este zip (adaptado al port 1.777 / parches v33)
- `libil.so` — **no viene**: hay que compilarlo con el código de este zip (GitHub Actions, ver abajo). El
  compilado anterior es de una versión sin registro de diagnóstico; no lo uses.
- `apk_files/lib/arm64-v8a/libisaacport.so` — tu `libisaacport.so` parcheado (6 bytes: la dependencia
  `liblog.so` pasa a llamarse `libil.so`). El pack 1.777 solo cambia dex, manifest, `resources.arsc` y
  `port_patches.bin`, así que `libisaacport.so` e `isaac.arm64` son los de la 1.77. Comprueba que el tuyo es
  idéntico: `sha256sum` debe dar `afa41beb6b333968ec99c0d6d1a1ac7971ef2fb68376ba993a2f030a7d7f4948`.
  Si da otro, no uses el mío: `python3 tools/patch_needed.py ORIGINAL.so SALIDA.so` con el tuyo.
- `src/`, `scripts/`, `third_party/lua-5.3.3/` (Lua 5.3.3 sin modificar, MIT), `tools/`, `test/`.
- Convive con tu `port_patches.bin` (v33): no lo toca.

## Hacer el APK: usa SIEMPRE tu APK original como base (`tools/make_apk.sh`)
Extraer el APK a una carpeta y volver a comprimirlo **cambia cómo van guardados los archivos**: lo que iba sin
comprimir (recursos grandes que el juego lee por posición) pasa a ir comprimido, el APK baja de tamaño
(1.3 GB -> 900 MB en tu caso) y el juego puede quedarse en pantalla negra. `make_apk.sh` no recomprime nada:
copia cada entrada con su mismo método, cambia solo lo necesario, alinea y firma.
```
sh tools/make_apk.sh TU_ORIGINAL.apk SALIDA.apk RUTA/libil.so [CARPETA_PARCHE_1777]
```
- Toma el `libisaacport.so` **de tu APK** y le aplica el parche (no depende de copias mías).
- Comprobación: `SALIDA.apk` debe pesar casi lo mismo que el original (solo +~0.3 MB por `libil.so`).
- Si tu original no es la 1.777 y quieres el pack de parches, pasa como 4º argumento la carpeta ya extraída del pack.
- Necesita `python3` y `apksigner`; sin `apksigner` deja `SALIDA_SIN_FIRMAR.apk` (no se instala).

## (alternativa) Hacer el APK desde una carpeta descomprimida
Un APK es un ZIP. Tu manifest dice `extractNativeLibs=false` y `targetSdk 35`, así que: las `.so` deben ir
**sin comprimir y alineadas**, y la firma debe ser **v2 o superior** (`apksigner`; `jarsigner` no basta).
1. En tu carpeta del juego (la que tiene `AndroidManifest.xml` y `lib/`): copia encima el pack de parches 1.777 y
   copia los dos archivos de `apk_files/lib/arm64-v8a/` a su `lib/arm64-v8a/` (reemplaza `libisaacport.so`, añade `libil.so`).
   (O deja que lo haga `sh tools/install_into_apk.sh CARPETA libil.so`.)
2. Termux: `pkg install python zip unzip apksigner`.
3. `sh tools/pack_apk.sh CARPETA salida.apk` (si no hay `apksigner` falla y deja `..._SIN_FIRMAR.apk`; no lo instales)
   `python3 tools/apk_info.py salida.apk` diagnostica firma, alineado y librerías.
   (antes:) `sh tools/pack_apk.sh CARPETA salida.apk` → zip + alineado (`tools/zipalign.py`, propio) + firma + verificación.
4. Instala `salida.apk`. Si ya tienes el juego instalado con **otra firma**, Android no deja actualizar:
   hay que desinstalar el anterior (respalda antes lo que no quieras perder).
**Las dos `.so` van juntas**: si falta `libil.so`, `libisaacport.so` no carga y el juego cierra al abrir.
Revisa `adb logcat -s isaaclua`: `autoboot: mods=...`, `isaaclua listo: N mod(s)`, `enganche por frame instalado`.

## Diagnóstico sin adb (pantalla negra, "no pasa nada")
Al cargar, `libil.so` crea `Android/media/com.tboi.modded1/` (o la carpeta que ya exista; prueba varias y lo anota),
`mods/` y `lua/`, y escribe **`isaaclua_log.txt`** ahí mismo. **Si ese archivo no aparece, `libil.so` no llegó a
cargar** (o no pudo escribir). Si aparece, su contenido dice en qué paso va todo (carpetas, etapa, mods, enganche,
"latido: N frames" que prueba que el juego sigue dibujando). El constructor solo crea carpetas y lanza un hilo;
Lua y los enganches arrancan en ese hilo.
Para localizar una pantalla negra crea `isaaclua_stage.txt` junto al registro con un número y reinicia el juego:
`0` solo registro · `1` + Lua y mods · `2` + enganche por frame · `3` todo (por defecto).
Si con `0` sigue negra, el problema no es mi código sino la carga de la librería o el propio port.

## Cómo engancha
`libisaacport.so` presenta cada frame llamando en orden a `shim_*_between_frames` (`void f(void)`, por PLT).
`libil.so` cambia el puntero GOT de `shim_items_between_frames` por un envoltorio que llama a la original y
dispara los callbacks. Solo se modifica un puntero de datos; no se parchea código máquina. Si `libil.so`
carga antes que `libisaacport` (es lo normal con este parche), el enganche reintenta cada 50 ms hasta 60 s.

## Callbacks
| callback | origen |
|---|---|
| `MC_POST_RENDER` | real: una vez por frame presentado |
| `MC_POST_UPDATE` | **aproximado**: cada 2 frames de render (supone 60 fps / 30 ups) |
| los demás | **por calibrar** (ver abajo): enganches dentro de `isaac.arm64` |

### Enganches dentro de `isaac.arm64` (hooks.c) — sin calibrar
Misma técnica que los parches v33 del port: al primer frame, `libil.so` escribe `b cueva` en la primera
instrucción de 30 funciones candidatas del juego. Las cuevas van en una **página de memoria propia** pegada a
la imagen (a menos de 100 MB, alcance de `b`): leí `port_patches.bin` y los parches v33 ocupan prácticamente
todo el relleno de ceros de `__TEXT` (2317 palabras de ~2330 libres), así que no cabría nada si hay parches
activos; ese relleno solo queda como reserva. Cada cueva solo suma 1 a un contador y guarda `x0`/`x1` en un buzón de `libil.so`, ejecuta la instrucción desplazada y vuelve.
Cada frame `libil.so` lee los contadores y dispara los callbacks que tú hayas mapeado.
- Antes de tocar un sitio comprueba que su instrucción sea la original del binario y no dependa de PC;
  si no, lo omite y lo anota. Ninguno de los 30 sitios coincide con un sitio que toque el v33 (lo comprobé
  contra `port_patches.bin`). Las cuevas se escriben y se hacen ejecutables **antes** de desviar ninguna función.
- **Los 30 candidatos son hipótesis**: unos salen de las sondas del propio port (`HALLAZGOS_probes.md`),
  otros de funciones que contienen mensajes del juego ("Level::load_room…", "Entity TakeDamage…").
  Esas cadenas aparecen en varias funciones (hay copias o código incrustado), por eso hay 4 candidatos por mensaje.
- Un candidato equivocado **no cambia el juego**: solo dispararía el callback en momentos equivocados.
- **Por defecto no se dispara ningún callback desde ellos.** Se calibra así:
  1. Abre el juego y haz, con pausas de unos segundos: (a) quédate quieto 15 s, (b) cambia de sala,
     (c) recibe daño un enemigo, (d) usa el item activo, (e) empieza una partida nueva.
  2. Mira `Android/media/com.tboi.modded1/lua/hooks_log.txt` (se actualiza cada ~2 s): cuenta cada enganche.
     Un contador que sube 1 solo al cambiar de sala es el de `MC_POST_NEW_ROOM`; uno que sube ~30/s quieto es el update.
  3. Anota cuál subió en cada acción y pásamelo (o edita tú `hooks.cfg`, ver `hooks.cfg.example`).

## API de mods
`RegisterMod`, `AddCallback/AddPriorityCallback/RemoveCallback` (filtro por parámetro, `CallbackPriority`),
`SaveData/LoadData/HasData/RemoveData` (en `Android/media/com.tboi.modded1/lua/`), `Isaac.DebugString/
ConsoleOutput/GetFrameCount/GetTime`, `print`, `include()`, `require()` en la carpeta del mod, `Game():GetFrameCount()`.
Carpetas con `disable.it` se saltan. Un error en un mod o callback se registra y no afecta al resto.
Protecciones: sin `io`/procesos/código nativo, tope de 192 MB, límite de instrucciones por llamada, mutex.

## Pruebas hechas (todas en PC x86; **nada en Android/arm64**)
Núcleo 30/30; enganche GOT 17/17 con una biblioteca simulada (incluye carga tardía); enganches en el binario 17/17
con una imagen falsa (incluye el caso de relleno de `__TEXT` ya lleno), más una **emulación** de las 30 cuevas arm64 generadas (suman el contador, guardan x0/x1,
conservan la instrucción desplazada y vuelven a sitio+4); todo limpio con ASan, UBSan y ThreadSanitizer. El parche ELF se verificó con `readelf` (6 bytes distintos, mismo tamaño, 1245 símbolos
intactos). Sin verificar: que el linker de Android acepte la dependencia sustituida, y la ruta de mods real.
Tras `adb logcat` sabrás en qué paso falla, si falla.
