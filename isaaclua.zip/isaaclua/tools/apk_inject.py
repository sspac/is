#!/usr/bin/env python3
"""
apk_inject.py - cambia/anade archivos DENTRO de un APK existente sin tocar lo demas.

  python3 apk_inject.py ORIGINAL.apk SALIDA.apk [--set RUTA_EN_APK=ARCHIVO ...] [--overlay CARPETA ...]

- Cada entrada que no cambia se copia con SU MISMO metodo de compresion (lo que iba sin comprimir sigue
  sin comprimir: recursos grandes que el juego lee por posicion dejarian de funcionar si se comprimen).
- Las entradas reemplazadas conservan el metodo de la original; las nuevas van sin comprimir si son
  .so/.arsc y comprimidas si no.
- Quita las firmas viejas (META-INF/*.SF, *.RSA, *.DSA, *.EC, MANIFEST.MF): hay que volver a firmar.
- Alinea (4 bytes las entradas sin comprimir, 16384 las .so). Copia en trozos: no carga archivos enteros en memoria.
- --overlay CARPETA: todos sus archivos reemplazan/anaden la ruta relativa equivalente en el APK.
Firma despues con apksigner (esquema v2 o superior).
"""
import os, shutil, struct, sys, zipfile

ALIGN_SO, ALIGN_DEF = 16384, 4
SIG_EXT = ('.SF', '.RSA', '.DSA', '.EC')

def want(name, ctype):
    if ctype != zipfile.ZIP_STORED or name.endswith('/'): return 0
    return ALIGN_SO if name.endswith('.so') else ALIGN_DEF

def pad_extra(pos, name, a):
    if not a: return b''
    after = pos + 30 + len(name.encode('utf-8'))
    pad = (-after) % a
    if 0 < pad < 4: pad += a
    return struct.pack('<HH', 0xD935, pad - 4) + b'\0' * (pad - 4) if pad else b''

def method_for_new(name):
    return zipfile.ZIP_STORED if name.endswith(('.so', '.arsc')) else zipfile.ZIP_DEFLATED

def write_entry(zout, name, date_time, ctype, ext_attr, create_system, size_hint, reader):
    zi = zipfile.ZipInfo(name, date_time)
    zi.compress_type = ctype; zi.external_attr = ext_attr; zi.create_system = create_system
    zi.file_size = size_hint
    zi.extra = pad_extra(zout.fp.tell(), name, want(name, ctype))
    if name.endswith('/'):
        zout.writestr(zi, b''); return
    with zout.open(zi, 'w', force_zip64=size_hint > (1 << 30)) as dst:
        shutil.copyfileobj(reader, dst, 1 << 20)

def check(path):
    bad = total = 0
    with zipfile.ZipFile(path) as z, open(path, 'rb') as fp:
        for zi in z.infolist():
            a = want(zi.filename, zi.compress_type)
            if not a: continue
            total += 1
            fp.seek(zi.header_offset); h = fp.read(30)
            n, m = struct.unpack('<HH', h[26:30])
            if (zi.header_offset + 30 + n + m) % a: bad += 1; print('SIN ALINEAR:', zi.filename)
    return total, bad

def main(argv):
    if len(argv) < 3: print(__doc__); return 2
    src, dst = argv[1], argv[2]
    repl = {}; i = 3
    while i < len(argv):
        if argv[i] == '--set':
            k, _, v = argv[i + 1].partition('=')
            if not os.path.isfile(v): print('error: no existe', v); return 1
            repl[k] = v; i += 2
        elif argv[i] == '--overlay':
            root = argv[i + 1]
            if not os.path.isdir(root): print('error: no existe la carpeta', root); return 1
            for dp, _, fns in os.walk(root):
                for fn in fns:
                    full = os.path.join(dp, fn); rel = os.path.relpath(full, root).replace(os.sep, '/')
                    repl[rel] = full
            i += 2
        else: print('argumento desconocido:', argv[i]); return 2
    stats = dict(copiadas=0, reemplazadas=0, nuevas=0, firmas_quitadas=0, stored=0, deflated=0)
    done = set()
    with zipfile.ZipFile(src) as zin, zipfile.ZipFile(dst, 'w') as zout:
        for zi in zin.infolist():
            n = zi.filename
            if n.startswith('META-INF/') and (n.endswith(SIG_EXT) or n == 'META-INF/MANIFEST.MF'):
                stats['firmas_quitadas'] += 1; continue
            if n in repl:
                local = repl[n]
                with open(local, 'rb') as rd:
                    write_entry(zout, n, zi.date_time, zi.compress_type, zi.external_attr, zi.create_system, os.path.getsize(local), rd)
                stats['reemplazadas'] += 1; done.add(n)
                stats['stored' if zi.compress_type == 0 else 'deflated'] += 1
            else:
                with zin.open(zi) as rd:
                    write_entry(zout, n, zi.date_time, zi.compress_type, zi.external_attr, zi.create_system, zi.file_size, rd)
                stats['copiadas'] += 1
                stats['stored' if zi.compress_type == 0 else 'deflated'] += 1
        for n in sorted(set(repl) - done):
            local = repl[n]; ct = method_for_new(n)
            with open(local, 'rb') as rd:
                write_entry(zout, n, (2026, 1, 1, 0, 0, 0), ct, 0o100644 << 16, 3, os.path.getsize(local), rd)
            stats['nuevas'] += 1
            stats['stored' if ct == 0 else 'deflated'] += 1
    total, bad = check(dst)
    print('entradas copiadas sin cambios: %(copiadas)d | reemplazadas: %(reemplazadas)d | nuevas: %(nuevas)d | firmas viejas quitadas: %(firmas_quitadas)d' % stats)
    print('en la salida: %(stored)d sin comprimir, %(deflated)d comprimidas' % stats)
    print('tamano: %d -> %d bytes | alineado: %d entradas sin comprimir, %d sin alinear' % (os.path.getsize(src), os.path.getsize(dst), total, bad))
    return 1 if bad else 0

sys.exit(main(sys.argv))
