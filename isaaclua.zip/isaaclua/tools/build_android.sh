#!/bin/sh
# Compila libil.so (isaaclua) para Android arm64. Sin argumentos: usa el Lua incluido.
#  - Termux (celular):  pkg install clang   y luego:  sh tools/build_android.sh
#  - NDK en PC:         export ANDROID_NDK_HOME=/ruta/ndk   y el mismo comando.
# Opcionales: LUA=/otra/ruta/src  OUT=archivo.so  CC=compilador  API=24  NOAUTO=1
set -e
cd "$(dirname "$0")/.."
LUA="${LUA:-third_party/lua-5.3.3}"
OUT="${OUT:-libil.so}"
API="${API:-24}"
SRCS=$(ls "$LUA"/*.c 2>/dev/null || ls "$LUA"/src/*.c | grep -v -E '/(lua|luac)\.c$')
INC="$LUA"; [ -d "$LUA/src" ] && INC="$LUA/src"

if [ -n "$ANDROID_NDK_HOME" ]; then
  CC=$(ls "$ANDROID_NDK_HOME"/toolchains/llvm/prebuilt/*/bin/aarch64-linux-android${API}-clang | head -n1)
else
  CC="${CC:-clang}"
fi
AUTO="-DISAACLUA_AUTOBOOT"; [ -n "$NOAUTO" ] && AUTO=""

# soname libil.so: ese nombre (8 letras) es el que patch_needed.py escribe en libisaacport.so
# max-page-size=16384: compatible con dispositivos Android de paginas de 16 KB
"$CC" -shared -fPIC -O2 -fvisibility=hidden -DLUA_USE_POSIX $AUTO -pthread \
  -I"$INC" $SRCS src/isaaclua.c src/frame_hook.c src/hooks.c src/autoboot.c \
  -o "$OUT" -llog -lm -ldl -Wl,-soname,libil.so -Wl,-z,max-page-size=16384
echo "listo: $OUT"
