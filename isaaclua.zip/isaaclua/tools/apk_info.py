#!/usr/bin/env python3
"""apk_info.py - diagnostico rapido de un APK: firma, alineado, librerias y archivos clave.
Uso: python3 apk_info.py ARCHIVO.apk"""
import struct, sys, zipfile

def local_off(fp, zi):
    fp.seek(zi.header_offset); h = fp.read(30)
    n, m = struct.unpack('<HH', h[26:30]); return zi.header_offset + 30 + n + m

path = sys.argv[1] if len(sys.argv) > 1 else sys.exit(__doc__)
data = open(path, 'rb').read()
print('archivo: %s (%d bytes)' % (path, len(data)))
try:
    z = zipfile.ZipFile(path)
except Exception as e:
    sys.exit('NO ES UN ZIP VALIDO: %s' % e)
names = [i.filename for i in z.infolist()]
bad = z.testzip()
print('integridad del zip:', 'OK' if bad is None else 'DANADO en %s' % bad)

v2 = b'APK Sig Block 42' in data
v1 = [n for n in names if n.startswith('META-INF/') and n.endswith(('.RSA', '.DSA', '.EC'))]
print('\nFIRMA')
print('  v1 (META-INF):', ', '.join(v1) if v1 else 'NO')
print('  v2/v3 (bloque de firma):', 'SI' if v2 else 'NO')
if not v2:
    print('  >>> SIN FIRMA v2+: con targetSdk 35 Android lo rechaza ("el paquete no es valido").')

print('\nARCHIVOS CLAVE')
for n in ('AndroidManifest.xml', 'classes.dex', 'resources.arsc'):
    if n in names:
        zi = z.getinfo(n)
        extra = ''
        if n == 'resources.arsc':
            ok = zi.compress_type == 0 and local_off(open(path, 'rb'), zi) % 4 == 0
            extra = '  (debe ir SIN comprimir y alineado: %s)' % ('OK' if ok else 'MAL')
        print('  %-22s %9d bytes, %s%s' % (n, zi.file_size, 'sin comprimir' if zi.compress_type == 0 else 'comprimido', extra))
    else:
        print('  %-22s FALTA' % n)

print('\nLIBRERIAS (deben ir sin comprimir y alineadas a 16384)')
fp = open(path, 'rb'); problems = 0
for zi in z.infolist():
    if zi.filename.startswith('lib/') and zi.filename.endswith('.so'):
        off = local_off(fp, zi)
        ok = zi.compress_type == 0 and off % 16384 == 0
        problems += (not ok)
        print('  %-36s %9d  %s  alineado:%s' % (zi.filename, zi.file_size, 'sin comprimir' if zi.compress_type == 0 else 'COMPRIMIDO', 'OK' if off % 16384 == 0 else 'MAL (%d)' % (off % 16384)))
if not any(n.startswith('lib/arm64-v8a/libil.so') for n in names): print('  >>> falta lib/arm64-v8a/libil.so')
stale = [n for n in names if n.endswith('.orig')]
if stale: print('  >>> sobran archivos .orig:', stale)
print('\nRESUMEN:', 'firmado y listo' if (v2 and not problems and bad is None) else 'HAY PROBLEMAS (ver arriba)')
