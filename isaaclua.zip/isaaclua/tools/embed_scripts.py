#!/usr/bin/env python3
"""Regenera src/embedded_scripts.h a partir de scripts/*.lua (solo hace falta si editas los .lua)."""
import os
here = os.path.dirname(os.path.abspath(__file__))
root = os.path.dirname(here)
out = ["/* GENERADO por tools/embed_scripts.py - no editar a mano */\n"]
for name in ("enums", "main"):
    data = open(os.path.join(root, "scripts", name + ".lua"), "rb").read()
    out.append("static const unsigned char il_%s_lua[] = {\n" % name)
    for i in range(0, len(data), 16):
        out.append("  " + ",".join("0x%02x" % b for b in data[i:i+16]) + ",\n")
    out.append("  0x00\n};\nstatic const unsigned int il_%s_lua_len = %d;\n" % (name, len(data)))
open(os.path.join(root, "src", "embedded_scripts.h"), "w").write("".join(out))
print("ok")
