#!/bin/sh
# Hace el APK con isaaclua A PARTIR DE TU APK ORIGINAL (recomendado: no recomprime nada).
# Uso: sh tools/make_apk.sh ORIGINAL.apk SALIDA.apk RUTA/libil.so [CARPETA_PARCHE_1777]
#   - toma el libisaacport.so de TU apk y le aplica el parche de dependencia (no usa copias mias)
#   - mete libil.so, quita firmas viejas, alinea y firma con apksigner (v2+)
set -e
ORIG="${1:?uso: make_apk.sh ORIGINAL.apk SALIDA.apk libil.so [CARPETA_PARCHE]}"
OUT="${2:?falta SALIDA.apk}"
LIBIL="${3:?falta libil.so}"
OVERLAY="$4"
HERE="$(cd "$(dirname "$0")" && pwd)"
KS="${KS:-$HOME/isaaclua-debug.keystore}"
for f in "$ORIG" "$LIBIL"; do [ -f "$f" ] || { echo "error: no existe $f"; exit 1; }; done
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT

echo "1) sacando libisaacport.so de tu APK"
python3 - "$ORIG" "$TMP/libisaacport.orig.so" <<'PY'
import sys, zipfile, hashlib
z = zipfile.ZipFile(sys.argv[1]); d = z.read('lib/arm64-v8a/libisaacport.so')
open(sys.argv[2], 'wb').write(d); print('   sha256:', hashlib.sha256(d).hexdigest())
PY
echo "2) parcheando su dependencia"
python3 "$HERE/patch_needed.py" "$TMP/libisaacport.orig.so" "$TMP/libisaacport.so"

echo "3) inyectando en el APK (sin recomprimir lo demas)"
if [ -n "$OVERLAY" ]; then
  python3 "$HERE/apk_inject.py" "$ORIG" "$TMP/u.apk" --overlay "$OVERLAY" \
    --set lib/arm64-v8a/libisaacport.so="$TMP/libisaacport.so" --set lib/arm64-v8a/libil.so="$LIBIL"
else
  python3 "$HERE/apk_inject.py" "$ORIG" "$TMP/u.apk" \
    --set lib/arm64-v8a/libisaacport.so="$TMP/libisaacport.so" --set lib/arm64-v8a/libil.so="$LIBIL"
fi

echo "4) firmando"
if [ ! -f "$KS" ]; then
  keytool -genkeypair -keystore "$KS" -storepass android -keypass android -alias isaaclua \
    -keyalg RSA -keysize 2048 -validity 10000 -dname "CN=isaaclua" >/dev/null 2>&1
fi
if command -v apksigner >/dev/null; then
  apksigner sign --ks "$KS" --ks-pass pass:android --key-pass pass:android --out "$OUT" "$TMP/u.apk"
  apksigner verify -v "$OUT" | grep -E "Verifies|Verified using v[0-9]+ scheme .*: true"
  echo "LISTO (firmado y verificado): $OUT"
else
  SIN="${OUT%.apk}_SIN_FIRMAR.apk"; cp "$TMP/u.apk" "$SIN"
  echo "ERROR: no hay apksigner (pkg install apksigner). Quedo sin firmar: $SIN  -- NO lo instales asi"; exit 1
fi
