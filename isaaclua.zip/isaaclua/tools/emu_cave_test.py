#!/usr/bin/env python3
"""Ejecuta (emulando) las cuevas arm64 generadas por hooks.c y comprueba su efecto.
Uso: python3 tools/emu_cave_test.py /tmp/hooks_dump.txt"""
import sys, struct
def sx(v, b): return v - (1 << b) if v & (1 << (b - 1)) else v

def run_cave(words, cave_addr, regs, mem, expect_back):
    pc = cave_addr; steps = 0
    while True:
        i = (pc - cave_addr) // 4
        w = words[i]; steps += 1
        if steps > 64: raise SystemExit('bucle en la cueva')
        if (w & 0xFF800000) == 0xD2800000:      # movz x
            rd = w & 31; hw = (w >> 21) & 3; regs[rd] = ((w >> 5) & 0xffff) << (16 * hw)
        elif (w & 0xFF800000) == 0xF2800000:    # movk x
            rd = w & 31; hw = (w >> 21) & 3; imm = (w >> 5) & 0xffff
            regs[rd] = (regs[rd] & ~(0xffff << (16 * hw))) | (imm << (16 * hw))
        elif (w & 0xFFC00000) == 0xB9400000:    # ldr w, [xn, #imm]
            rt, rn, imm = w & 31, (w >> 5) & 31, ((w >> 10) & 0xfff) * 4
            regs[rt] = mem.get(regs[rn] + imm, 0) & 0xffffffff
        elif (w & 0xFFC00000) == 0xB9000000:    # str w, [xn, #imm]
            rt, rn, imm = w & 31, (w >> 5) & 31, ((w >> 10) & 0xfff) * 4
            mem[regs[rn] + imm] = regs[rt] & 0xffffffff
        elif (w & 0xFF800000) == 0x11000000:    # add w, w, #imm
            rd, rn, imm = w & 31, (w >> 5) & 31, (w >> 10) & 0xfff
            regs[rd] = (regs[rn] + imm) & 0xffffffff
        elif (w & 0xFFC00000) == 0xA9000000:    # stp x, x, [xn, #imm]
            rt, rn, rt2, imm = w & 31, (w >> 5) & 31, (w >> 10) & 31, sx((w >> 15) & 0x7f, 7) * 8
            mem[regs[rn] + imm] = regs[rt]; mem[regs[rn] + imm + 8] = regs[rt2]
        elif (w >> 26) == 0x05:                 # b
            return pc + sx(w & 0x3ffffff, 26) * 4, steps
        else:
            yield_orig = w   # instruccion desplazada: se copia tal cual, no se ejecuta aqui
            if w != expect_back['orig']: raise SystemExit('instruccion inesperada %08x en la cueva' % w)
            expect_back['seen_orig'] = True
        pc += 4

def main():
    lines = open(sys.argv[1]).read().split('\n')
    base = int(lines[0].split()[1], 16)
    ok = bad = 0; i = 1
    while i < len(lines) and lines[i].startswith('hook'):
        h = lines[i].split(); words = [int(x, 16) for x in lines[i + 1].split()]
        site = int(h[3], 16); cave = int(h[5], 16); orig = int(h[7], 16)   # direcciones absolutas
        # el sitio debe saltar a la cueva
        # (la direccion del buzon la reconstruye la propia cueva con movz/movk)
        regs = [0] * 32; regs[0] = 0x1122334455667788; regs[1] = 0x99AABBCC
        mem = {}
        info = {'orig': orig, 'seen_orig': False}
        for rep in (1, 2):
            back, steps = run_cave(words, cave, regs, mem, info)
            slot = regs[16]
            good = (back == site + 4 and info['seen_orig'] and mem[slot] == rep and
                    mem[slot + 8] == 0x1122334455667788 and mem[slot + 16] == 0x99AABBCC)
            if not good:
                print('FALLA hook', h[1], 'rep', rep, hex(back), hex(site + 4), mem.get(slot)); bad += 1; break
        else:
            ok += 1
        i += 2
    print('cuevas emuladas: %d ok, %d con fallo' % (ok, bad))
    sys.exit(1 if bad else 0)
main()
