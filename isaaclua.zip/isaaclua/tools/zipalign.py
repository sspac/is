#!/usr/bin/env python3
"""
zipalign.py - alinea un APK (sin depender de la herramienta zipalign de Android).

  python3 zipalign.py ENTRADA.apk SALIDA.apk      alinea
  python3 zipalign.py --check ARCHIVO.apk          solo comprueba (sale con 1 si algo no esta alineado)

Reglas (las que exige Android con extractNativeLibs=false):
  - entradas SIN comprimir: datos alineados a 4 bytes
  - librerias .so sin comprimir: alineadas a 16384 bytes (vale tambien para paginas de 4 KB)
Las entradas comprimidas no se tocan. Se conserva el contenido, el orden y las fechas.
IMPORTANTE: alinear ANTES de firmar (la firma v2 cubre el archivo entero).
"""
import struct, sys, zipfile

ALIGN_SO = 16384
ALIGN_DEFAULT = 4

def want(zi):
    if zi.compress_type != zipfile.ZIP_STORED or zi.filename.endswith('/'):
        return 0
    return ALIGN_SO if zi.filename.endswith('.so') else ALIGN_DEFAULT

def local_data_offset(fp, zi):
    fp.seek(zi.header_offset)
    h = fp.read(30)
    if h[:4] != b'PK\x03\x04': raise SystemExit('cabecera local invalida en %s' % zi.filename)
    n, m = struct.unpack('<HH', h[26:30])
    return zi.header_offset + 30 + n + m

def check(path):
    bad = 0; total = 0
    with zipfile.ZipFile(path) as z, open(path, 'rb') as fp:
        for zi in z.infolist():
            a = want(zi)
            if not a: continue
            total += 1
            off = local_data_offset(fp, zi)
            if off % a:
                bad += 1; print('SIN ALINEAR (%d): %s  offset=%d' % (a, zi.filename, off))
    print('%d entradas sin comprimir revisadas, %d sin alinear' % (total, bad))
    return 1 if bad else 0

def align(src, dst):
    import shutil
    with zipfile.ZipFile(src) as zin, zipfile.ZipFile(dst, 'w') as zout:
        for zi in zin.infolist():
            new = zipfile.ZipInfo(zi.filename, zi.date_time)
            new.compress_type = zi.compress_type
            new.external_attr = zi.external_attr
            new.create_system = zi.create_system
            new.file_size = zi.file_size
            extra = b''
            a = want(zi)
            if a:
                name_len = len(zi.filename.encode('utf-8'))
                after = zout.fp.tell() + 30 + name_len
                pad = (-after) % a
                if 0 < pad < 4: pad += a
                if pad: extra = struct.pack('<HH', 0xD935, pad - 4) + b'\0' * (pad - 4)
            new.extra = extra
            if zi.filename.endswith('/'):
                zout.writestr(new, b'')
            else:
                with zin.open(zi) as rd, zout.open(new, 'w', force_zip64=zi.file_size > (1 << 30)) as wr:
                    shutil.copyfileobj(rd, wr, 1 << 20)
    return check(dst)

if __name__ == '__main__':
    if len(sys.argv) == 3 and sys.argv[1] == '--check':
        sys.exit(check(sys.argv[2]))
    if len(sys.argv) == 3:
        sys.exit(align(sys.argv[1], sys.argv[2]))
    print(__doc__); sys.exit(2)
