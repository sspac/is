#!/bin/sh
# Compila y corre las pruebas en PC (usa el Lua incluido). Uso: sh tools/build_host.sh
set -e
cd "$(dirname "$0")/.."
LUA="${LUA:-third_party/lua-5.3.3}"
SRCS=$(ls "$LUA"/*.c)
CF="-O1 -g -Wall -Wextra -DLUA_USE_POSIX -I$LUA -pthread"

echo "### pruebas del nucleo"
gcc $CF $SRCS src/isaaclua.c src/frame_hook.c src/hooks.c test/test_host.c -lm -ldl -o /tmp/isaaclua_test
rm -rf /tmp/isaaclua_saves
/tmp/isaaclua_test scripts test/mods /tmp/isaaclua_saves

echo; echo "### pruebas del enganche por frame (biblioteca simulada)"
gcc -shared -fPIC -O1 test/mock/mock_game.c test/mock/mock_present.c -o /tmp/libmock.so
gcc -shared -fPIC -O1 test/mock/mock_game.c test/mock/mock_present.c -o /tmp/libmock2.so
gcc $CF $SRCS src/isaaclua.c src/frame_hook.c src/hooks.c test/test_hook.c -lm -ldl -o /tmp/isaaclua_hooktest
/tmp/isaaclua_hooktest /tmp/libmock.so test/mods_hook

echo; echo "### pruebas de enganches en isaac.arm64 (imagen falsa) + emulacion de las cuevas"
gcc $CF $SRCS src/isaaclua.c src/frame_hook.c src/hooks.c test/test_hooks.c -lm -ldl -o /tmp/isaaclua_hk2
/tmp/isaaclua_hk2 /tmp/hooks_dump.txt
python3 tools/emu_cave_test.py /tmp/hooks_dump.txt

set +e
echo; echo "### pruebas del arranque automatico (carpetas, registro, etapas)"
gcc $CF -DISAACLUA_AUTOBOOT $SRCS src/isaaclua.c src/frame_hook.c src/hooks.c src/autoboot.c test/test_autoboot.c -lm -ldl -o /tmp/isaaclua_autoboot
B=/tmp/il_auto; rm -rf $B; mkdir -p $B/mods; cp -r test/mods_hook/frames $B/mods/
fails=0; ok() { if [ "$1" = 0 ]; then echo "  ok:    $2"; else echo "  FALLA: $2"; fails=$((fails+1)); fi; }
ISAACLUA_BASE=$B /tmp/isaaclua_autoboot 1 >/dev/null; ok $? "etapa 3 (por defecto): carga el mod de prueba"
grep -q "libil.so cargada" $B/isaaclua_log.txt; ok $? "el registro existe y dice que la libreria cargo"
grep -q "stage=3" $B/isaaclua_log.txt; ok $? "el registro indica la etapa"
grep -q "candidato EXISTE .*$B" $B/isaaclua_log.txt; ok $? "el registro lista los candidatos de carpeta"
grep -q "mod cargado: frames" $B/isaaclua_log.txt; ok $? "el registro lista el mod cargado"
[ -d $B/lua ]; ok $? "se crea la carpeta lua/"
echo 0 > $B/isaaclua_stage.txt; ISAACLUA_BASE=$B /tmp/isaaclua_autoboot 0 >/dev/null; ok $? "etapa 0: Lua NO arranca (0 mods)"
grep -q "etapa 1 desactivada" $B/isaaclua_log.txt; ok $? "y el registro lo dice"
rm -rf /tmp/il_auto2; ISAACLUA_BASE=/tmp/il_auto2 /tmp/isaaclua_autoboot 0 >/dev/null; [ -d /tmp/il_auto2/mods ]; ok $? "sin carpeta mods/: la crea vacia"
[ $fails = 0 ] && echo "autoboot: todo ok" || { echo "autoboot: $fails fallos"; exit 1; }
