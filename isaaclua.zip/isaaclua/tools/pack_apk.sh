#!/bin/sh
# Empaqueta una carpeta de APK descomprimido, la alinea y la firma.
# Uso: sh tools/pack_apk.sh CARPETA_APK SALIDA.apk [keystore]
# Necesita: zip, python3 y apksigner (Termux: pkg install zip python apksigner). El alineado lo hace tools/zipalign.py.
# Crea un keystore de depuracion si no existe (keytool).
set -e
DIR="${1:?uso: pack_apk.sh CARPETA_APK SALIDA.apk [keystore]}"
OUT="$(cd "$(dirname "${2:?falta SALIDA.apk}")" && pwd)/$(basename "$2")"
KS="${3:-$HOME/isaaclua-debug.keystore}"
[ -f "$DIR/AndroidManifest.xml" ] || { echo "error: $DIR no parece un APK descomprimido (falta AndroidManifest.xml)"; exit 1; }
command -v zip >/dev/null || { echo "error: falta 'zip'"; exit 1; }

TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
rm -f "$OUT"
cd "$DIR"
# 1) todo lo comprimible, sin firmas viejas ni copias .orig
zip -q -r -X -0 "$TMP/u.apk" . -x 'lib/*' 'resources.arsc' 'META-INF/*.SF' 'META-INF/*.RSA' \
    'META-INF/*.DSA' 'META-INF/*.EC' 'META-INF/MANIFEST.MF' '*.orig'
# 2) sin comprimir: las .so y resources.arsc (Android moderno lo exige para alinearlas)
zip -q -r -X -0 "$TMP/u.apk" lib -x '*.orig'
[ -f resources.arsc ] && zip -q -X -0 "$TMP/u.apk" resources.arsc
cd - >/dev/null

# alineado: con extractNativeLibs=false las .so se leen directo del APK y deben ir alineadas
HERE="$(cd "$(dirname "$0")" && pwd)"
command -v python3 >/dev/null || { echo "error: falta python3 (pkg install python)"; exit 1; }
python3 "$HERE/zipalign.py" "$TMP/u.apk" "$TMP/a.apk"
python3 "$HERE/zipalign.py" --check "$TMP/a.apk" >/dev/null || { echo "error: el APK no quedo alineado"; exit 1; }

if [ ! -f "$KS" ]; then
  command -v keytool >/dev/null || { echo "error: falta keytool para crear el keystore"; exit 1; }
  keytool -genkeypair -keystore "$KS" -storepass android -keypass android -alias isaaclua \
    -keyalg RSA -keysize 2048 -validity 10000 -dname "CN=isaaclua" >/dev/null 2>&1
  echo "keystore creado: $KS"
fi
if command -v apksigner >/dev/null; then
  apksigner sign --ks "$KS" --ks-pass pass:android --key-pass pass:android --out "$OUT" "$TMP/a.apk"
  if apksigner verify -v "$OUT" | grep -E "Verifies|Verified using v[0-9]+ scheme .*: true"; then
    echo "LISTO (firmado y verificado): $OUT"
  else
    echo "ERROR: la firma no verifica. No instales $OUT"; exit 1
  fi
else
  SIN="${OUT%.apk}_SIN_FIRMAR.apk"
  cp "$TMP/a.apk" "$SIN"
  echo ""
  echo "=================================================================="
  echo " ERROR: no hay 'apksigner' y el APK NO esta firmado."
  echo " Android lo rechazara ('el paquete no es valido')."
  echo " Se dejo como: $SIN   (NO lo instales asi)"
  echo " Instala la herramienta con:  pkg install apksigner"
  echo " y vuelve a ejecutar este mismo comando."
  echo "=================================================================="
  exit 1
fi
